# 🤖 Agentic Playground (People Playground Mod)

**Agentic Playground** connects **People Playground** to **Google's Gemini API**, introducing an autonomous, perceptive AI Director that can manipulate the sandbox world, interact with the game interface, and converse with the player.

---

## ✨ Features

- **🧠 Perceptive Gemini AI Director**:
  - The AI perceives real-time scene state: living humans, dead corpses, burning items, active weapons, physics objects, and camera position.
  - Understands complex natural language instructions and translates them into in-game actions.

- **🎮 Comprehensive World & Physics Manipulation**:
  - **Spawning**: Humans, Androids, Gorses, Swords, Firearms (Shotguns, Pistols, RPGs, Sniper Rifles), Explosives (C4, Nuclear Bombs, Grenades, Dynamite), Syringes (Life, Death, Acid, Freeze), Vehicles, and Props.
  - **Explosions & Shockwaves**: Generates calibrated conventional explosions or pulse shockwaves with custom radius and force.
  - **Fire & Thermal**: Ignites targets (everything, corpses, or random items) and extinguishes all active fires.
  - **Cryogenics**: Freezes limbs and physics bodies in place or unfreezes them.
  - **Matter Disintegration**: Turns targets or corpses into ash.
  - **Resuscitation & Healing**: Heals broken bones, stops bleeding, resets shock/pain levels, and restores consciousness.
  - **Telekinesis & Force**: Applies directional physics impulses or launches objects into the air.
  - **Anti-Gravity (Zero-G)**: Toggles zero gravity on objects in the arena.
  - **Interface & Simulation**: Controls pause, slow motion, clean up debris, and displays in-game speech notifications.

- **💬 Interactive In-Game HUD & Window (Toggle with `F8` or On-Screen Button)**:
  - **Chat & Direct Orders Tab**: Type any prompt or tap quick chips (e.g. *Gladiator Fight*, *Pulse Shockwave*, *Zero-G Chaos*, *Revive & Heal*).
  - **Autonomous Agentic Mode Tab**: Enable autonomous mode so Gemini continuously monitors the arena and automatically orchestrates experiments, disasters, or rescues every few seconds!
  - **Personality Presets**: *Playful Director*, *Chaotic Mad Scientist*, *Gentle Caretaker*, *Destructive Overlord*.
  - **Quick Sandbox Palette Tab**: Instant one-click spawns, healing, gravity toggles, and cleanups.
  - **Config Tab**: Easily enter/paste your Gemini API Key directly in-game and choose your model (`gemini-2.5-flash`, `gemini-1.5-flash`, etc.).

---

## 🚀 Getting Started

### 1. Launch People Playground
The mod is installed in:
- Desktop: `C:\Users\A.Y TRADERS\Desktop\agenticplaygroun`
- Game Mods folder: `D:\games\People.Playground.v1.27.11\...\Mods\agenticplayground`

1. Launch `People Playground.exe`.
2. On the main menu, click **Mods**.
3. Ensure **Agentic Playground** is toggled **Active / Enabled** (green checkmark).
4. Load any map (e.g., *Default*, *Humongous*, *Tower*, *Blocks*).

### 2. Open the AI Interface
- Press **`F8`** on your keyboard, OR click the **`[🤖 Agentic AI (F8)]`** button at the top-right corner of your screen.
- Go to the **⚙️ Config & Key** tab.
- Paste your **Gemini API Key** and click **💾 Save Configuration**.
- Click **🧪 Test Connection** to verify your setup.

### 3. Direct the AI
Switch to the **💬 Chat & Orders** tab and issue commands like:
- *"Spawn 2 humans, arm them with swords, and start a gladiator fight!"*
- *"Trigger an anti-gravity explosion at the center of the room."*
- *"Heal all wounded humans and put out all fires."*
- *"Drop a nuclear bomb and activate slow motion."*
- *"What is happening in the room right now?"*

### 4. Autonomous Agentic Mode
- Open the **🧠 Autonomous** tab.
- Check **Enable Autonomous AI Director**.
- Select a personality (e.g. *Chaotic Mad Scientist*).
- Sit back and watch the AI observe your sandbox and manipulate the world autonomously!

---

## 🛠️ File Structure
```
agenticplaygroun/
├── mod.json                # Mod manifest for People Playground
├── AgenticPlayground.cs     # Main mod script (ModAPI, Gemini client, GUI, Action engine)
├── config.json             # Saved settings (API key, model, personality, toggle key)
├── thumb.png               # Mod thumbnail image
└── README.md               # Documentation and usage guide
```
