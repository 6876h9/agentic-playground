using System;
using System.IO;
using System.Reflection;
using UnityEngine;

namespace AgenticPlaygroundMod
{
    public class ModEntryPoint
    {
        public static void Main()
        {
            try
            {
                string currentDir = Directory.GetCurrentDirectory();
                string dllPath = Path.Combine(currentDir, "Mods", "agenticplayground", "AgenticPlaygroundCore.dll");
                
                if (!File.Exists(dllPath))
                {
                    dllPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "agenticplaygroun", "AgenticPlaygroundCore.dll");
                }

                if (!File.Exists(dllPath))
                {
                    string modsDir = Path.Combine(currentDir, "Mods");
                    if (Directory.Exists(modsDir))
                    {
                        string[] matches = Directory.GetFiles(modsDir, "AgenticPlaygroundCore.dll", SearchOption.AllDirectories);
                        if (matches.Length > 0)
                        {
                            dllPath = matches[0];
                        }
                    }
                }

                if (File.Exists(dllPath))
                {
                    byte[] rawAssembly = File.ReadAllBytes(dllPath);
                    Assembly loadedAssembly = Assembly.Load(rawAssembly);
                    Type managerType = loadedAssembly.GetType("AgenticPlaygroundMod.AgenticPlaygroundManager");
                    if (managerType != null)
                    {
                        MethodInfo initMethod = managerType.GetMethod("Initialize", BindingFlags.Public | BindingFlags.Static);
                        if (initMethod != null)
                        {
                            initMethod.Invoke(null, null);
                            return;
                        }
                    }
                }
                else
                {
                    ModAPI.Notify("AgenticPlaygroundCore.dll not found!");
                }
            }
            catch (Exception ex)
            {
                Debug.LogError("[AgenticPlayground] Initialization failed: " + ex);
                ModAPI.Notify("Agentic Playground Error: " + ex.Message);
            }
        }
    }
}
